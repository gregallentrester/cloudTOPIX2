package com.ecwid.consul;

public class ConsulTestConstants {

	public static final String CONSUL_VERSION = "1.6.0";

}
