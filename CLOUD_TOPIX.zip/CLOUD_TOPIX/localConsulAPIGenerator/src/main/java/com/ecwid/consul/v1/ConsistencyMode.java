package com.ecwid.consul.v1;

/**
 * @author Vasily Vasilkov (vgv@ecwid.com)
 */
public enum ConsistencyMode {

	DEFAULT,

	STALE,

	CONSISTENT
}
