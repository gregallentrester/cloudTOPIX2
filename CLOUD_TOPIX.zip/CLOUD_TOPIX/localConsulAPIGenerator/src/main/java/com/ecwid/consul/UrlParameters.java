package com.ecwid.consul;

import java.util.List;

/**
 * @author Vasily Vasilkov (vgv@ecwid.com)
 */
public interface UrlParameters {

	public List<String> toUrlParameters();

}
