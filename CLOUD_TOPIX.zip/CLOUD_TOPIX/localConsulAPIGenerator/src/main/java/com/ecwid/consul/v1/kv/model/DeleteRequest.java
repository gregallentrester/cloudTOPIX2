package com.ecwid.consul.v1.kv.model;

/**
 * @author Vasily Vasilkov (vgv@ecwid.com)
 */
public class DeleteRequest {
}
