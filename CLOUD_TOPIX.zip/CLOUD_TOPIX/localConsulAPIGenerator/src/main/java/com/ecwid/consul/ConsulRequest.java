package com.ecwid.consul;

import java.util.List;

public interface ConsulRequest {

	public List<UrlParameters> asUrlParameters();

}
