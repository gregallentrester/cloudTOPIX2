package net.greg.docker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.web.bind.annotation.*;


@SpringBootApplication
public class App {

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}

  @RestController
  static final class Compass {

    @GetMapping("/")
		public String a() {
			return PAGE1 + PAGE2;
		}

		@GetMapping("/west")
		public String b() {
			return PAGE1 + "ouest" + PAGE2;
		}

		@GetMapping("/east")
		public String c() {
			return PAGE1 + "est" + PAGE2;
		}

		@GetMapping("/north")
		public String d() {
			return PAGE1 + "nord" + PAGE2;
		}

		@GetMapping("/south")
		public Object e() {
			return PAGE1 + "sou" + PAGE2;
		}

		@RequestMapping(value={"/{id}"}, method = RequestMethod.GET)
		public String zibble(@PathVariable String id) {
			return PAGE1 + id + PAGE2;
		}
	}

	private static final String PAGE1 =
		"<!DOCTYPE html><html lang='en-US'><link rel='stylesheet'" +
		" type='text/css' href='/css/style.css' /><a href=''>";

	private static final String PAGE2 =
		"</a><hr>";
}
